require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

const pageRoutes = require('./routes/pageRoutes');
const movieRoutes = require('./routes/movieRoutes');
const userRoutes = require('./routes/userRoutes');

app.use('/', pageRoutes);
app.use('/movies', movieRoutes);
app.use('/users', userRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// Підключення REST API для фільмів
const movieApiRoutes = require('./routes/api/movies');
app.use('/api/movies', express.json(), movieApiRoutes);

const authRoutes = require('./routes/api/auth');
const { authMiddleware, roleMiddleware } = require('./middleware/auth');

app.use(express.json()); // один раз, для всіх JSON запитів

app.use('/api/auth', authRoutes); // логін/реєстрація — публічні
app.use('/api/movies', authMiddleware, movieApiRoutes); // тільки з токеном

