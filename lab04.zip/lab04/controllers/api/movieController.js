const Movie = require('../../models/movie');

// Отримати всі фільми
exports.getAllMovies = async (req, res) => {
    try {
        const movies = await Movie.find();
        res.json(movies);
    } catch (err) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
};

// Отримати фільм за ID
exports.getMovieById = async (req, res) => {
    try {
        const movie = await Movie.findById(req.params.id);
        if (!movie) return res.status(404).json({ error: 'Фільм не знайдено' });
        res.json(movie);
    } catch (err) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
};

// Створити новий фільм
exports.createMovie = async (req, res) => {
    const { title, director, year } = req.body;
    if (!title || !director || !year) {
        return res.status(401).json({ error: 'Невалідні вхідні дані' });
    }
    try {
        const newMovie = new Movie({ title, director, year });
        await newMovie.save();
        res.status(201).json(newMovie);
    } catch (err) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
};

// Оновити фільм
exports.updateMovie = async (req, res) => {
    const { title, director, year } = req.body;
    if (!title || !director || !year) {
        return res.status(401).json({ error: 'Невалідні вхідні дані' });
    }
    try {
        const updatedMovie = await Movie.findByIdAndUpdate(
            req.params.id,
            { title, director, year },
            { new: true }
        );
        if (!updatedMovie) return res.status(404).json({ error: 'Фільм не знайдено' });
        res.json(updatedMovie);
    } catch (err) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
};

// Видалити фільм
exports.deleteMovie = async (req, res) => {
    try {
        const deletedMovie = await Movie.findByIdAndDelete(req.params.id);
        if (!deletedMovie) return res.status(404).json({ error: 'Фільм не знайдено' });
        res.json({ message: 'Фільм видалено' });
    } catch (err) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
};
