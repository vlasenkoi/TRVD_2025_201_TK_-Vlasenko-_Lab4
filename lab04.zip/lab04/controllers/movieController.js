const Movie = require('../models/movie');

exports.getAllMovies = async (req, res) => {
  const movies = await Movie.find();
  res.render('pages/movies', { movies });
};

exports.createMovieForm = (req, res) => {
  res.render('pages/createMovie');
};

exports.createMovie = async (req, res) => {
  const { title, description, year, genre } = req.body;
  await Movie.create({ title, description, year, genre });
  res.redirect('/movies');
};

exports.editMovieForm = async (req, res) => {
  const movie = await Movie.findById(req.params.id);
  res.render('pages/editMovie', { movie });
};

exports.updateMovie = async (req, res) => {
  const { title, description, year, genre } = req.body;
  await Movie.findByIdAndUpdate(req.params.id, { title, description, year, genre });
  res.redirect('/movies');
};

exports.deleteMovie = async (req, res) => {
  await Movie.findByIdAndDelete(req.params.id);
  res.redirect('/movies');
};
