const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authMiddleware } = require('../middleware/auth');


router.get('/', userController.getAllUsers);
router.get('/create', userController.createUserForm);
router.get('/users', authMiddleware, async (req, res) => {
  router.get('/users/edit/:id', authMiddleware, userController.editUserForm);
  const users = await User.find();
  res.render('users', {
    users,
    role: req.user.role // передаємо роль користувача
  });
});
router.post('/create', userController.createUser);
router.post('/delete/:id', userController.deleteUser);

module.exports = router;
