const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');

router.get('/', movieController.getAllMovies);
router.get('/create', movieController.createMovieForm);
router.post('/create', movieController.createMovie);
router.get('/edit/:id', movieController.editMovieForm);
router.post('/edit/:id', movieController.updateMovie);
router.post('/delete/:id', movieController.deleteMovie);
router.get('/create', (req, res) => {
    res.render('pages/createMovie');
});


module.exports = router;
