const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  title: String,
  description: String,
  year: Number,
  genre: String
});

// Щоб уникнути OverwriteModelError:
module.exports = mongoose.models.Movie || mongoose.model('Movie', movieSchema);
